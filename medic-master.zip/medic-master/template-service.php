<?php get_header();
global $coder;
/* Template Name:Service */
?>

<!--Page Title-->
<section class="page-title text-center" style="
        background-color:<?php echo $coder['page_bg']['background-color'];?>;
        background-repeat:<?php echo $coder['page_bg']['background-repeat'];?>;
        background-size:<?php echo $coder['page_bg']['background-size'];?>;
        background-attachment:<?php echo $coder['page_bg']['background-attachment'];?>;
        background-position:<?php echo $coder['page_bg']['background-position'];?>;
        background-image:url(<?php echo $coder['page_bg']['background-image']; ?>);
        ">
    <div class="container">
        <div class="title-text">
            <h1><?php the_title(); ?></h1>
            <ul class="title-menu clearfix">
                <li>
                    <a href="<?php home_url(); ?>">home &nbsp;/</a>
                </li>
                <li><?php wp_title(' '); ?></li>
            </ul>
        </div>
    </div>
</section>
<!--End Page Title-->
<section class="service-overview section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="content-block">
                    <?php echo get_post_meta(get_the_ID(),'service_title',true); ?>
                    <?php echo get_post_meta(get_the_ID(),'service_desc',true); ?>
                    <a href="<?php echo get_post_meta(get_the_ID(),'service_btn_url',true); ?>" class="btn btn-style-one"><?php echo get_post_meta(get_the_ID(),'service_btn',true); ?></a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="accordion-section">
                    <div class="section-title">
                        <h3><?php echo get_post_meta(get_the_ID(),'faq_titles',true); ?></h3>
                    </div>
                    <div class="accordion-holder">
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            <?php
                            $faq = new WP_Query(array(
                                'post_type' => 'faq',
                                'posts_per_page' => -1
                            ));
                            $i=0;
                            while($faq->have_posts()) : $faq->the_post();
                                $i++;
                                ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="heading<?php echo $i; ?>">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $i; ?>" aria-expanded="false" aria-controls="collapse<?php echo $i; ?>">
                                                <?php the_title(); ?>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapse<?php echo $i; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo $i; ?>">
                                        <div class="panel-body">
                                            <?php the_content(); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile;wp_reset_postdata(); ?>
                        </div>
                    </div>

                </div>
            </div>
            <div class="service-box col-md-12">
                <div class="row">
                    <div class="col-md-6">
                        <img class="img-responsive" src="<?php echo get_post_meta(get_the_ID(),'service_im',true); ?>" alt="service-image">
                    </div>
                    <div class="col-md-6">
                        <div class="contents">
                            <div class="section-title">
                                <h3><?php echo get_post_meta(get_the_ID(),'service_ne',true); ?></h3>
                            </div>
                            <?php echo get_post_meta(get_the_ID(),'service_de',true); ?>
                            <a href="<?php echo get_post_meta(get_the_ID(),'service_btn2_url',true); ?>" class="btn btn-style-one"><?php echo get_post_meta(get_the_ID(),'service_btn2',true); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php echo do_shortcode("[service_carousel]"); ?>
<!--End Service Section-->
<?php get_footer(); ?>