<?php get_header();
global $coder;
/* Template Name:About */
?>

    <!--Page Title-->
    <section class="page-title text-center" style="
            background-color:<?php echo $coder['page_bg']['background-color'];?>;
            background-repeat:<?php echo $coder['page_bg']['background-repeat'];?>;
            background-size:<?php echo $coder['page_bg']['background-size'];?>;
            background-attachment:<?php echo $coder['page_bg']['background-attachment'];?>;
            background-position:<?php echo $coder['page_bg']['background-position'];?>;
            background-image:url(<?php echo $coder['page_bg']['background-image']; ?>);
            ">
        <div class="container">
            <div class="title-text">
                <h1><?php the_title(); ?></h1>
                <ul class="title-menu clearfix">
                    <li>
                        <a href="<?php home_url(); ?>">home &nbsp;/</a>
                    </li>
                    <li><?php wp_title(' '); ?></li>
                </ul>
            </div>
        </div>
    </section>
    <!--End Page Title-->

    <!-- Our Story -->
    <section class="story">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <img src="<?php echo get_post_meta(get_the_ID(),'story_img',true); ?>" class="responsive" alt="story">
                </div>
                <div class="col-md-6">
                    <div class="story-content">
                        <h2><?php echo get_post_meta(get_the_ID(),'story_title',true); ?></h2>
                        <?php echo get_post_meta(get_the_ID(),'story_desc',true); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Promo Video -->
    <section class="promo-video" style="background: url(<?php echo get_post_meta(get_the_ID(),'video_bg',true);?>);">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="block text-center">
                        <h6><?php echo get_post_meta(get_the_ID(),'video_title',true); ?></h6>
                        <h1><?php echo get_post_meta(get_the_ID(),'video_sub_title',true); ?></h1>
                        <a data-fancybox href="https://www.youtube.com/watch?v=<?php echo get_post_meta(get_the_ID(),'video_id',true); ?>&amp;autoplay=1&amp;rel=0&amp;controls=0&amp;showinfo=0"><i class="fa fa-play"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="gallery bg-gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title text-center">
                        <h3><?php echo get_post_meta(get_the_ID(),'s_title_s',true); ?></h3>
                        <p><?php echo get_post_meta(get_the_ID(),'s_sub_desc',true); ?></p>
                    </div>
                </div>
                <?php
                $limit = get_post_meta(get_the_ID(),'s_post_limit',true);
                $shot = new WP_Query(array(
                    'post_type' => 'medic_shots',
                    'posts_per_page' => $limit
                ));
                while($shot->have_posts()) : $shot->the_post();
                    ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="gallery-item" >
                            <?php the_post_thumbnail(); ?>
                            <?php
                            $img_url = wp_get_attachment_url(get_post_thumbnail_id());
                            ?>
                            <a data-fancybox="images" href="<?php echo $img_url; ?>"></a>
                            <h3><?php the_title(); ?></h3>
                            <?php the_content(); ?>
                        </div>
                    </div>
                <?php endwhile;wp_reset_postdata(); ?>


            </div>
    </section>

    <!-- Contact Section -->
    <section class="appoinment-section section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="accordion-section">
                        <div class="section-title">
                            <h3><?php echo get_post_meta(get_the_ID(),'faq_titles',true); ?></h3>
                        </div>
                        <div class="accordion-holder">
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                <?php
                                $faq = new WP_Query(array(
                                    'post_type' => 'faq',
                                    'posts_per_page' => -1
                                ));
                                $i=0;
                                while($faq->have_posts()) : $faq->the_post();
                                    $i++;
                                    ?>
                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="heading<?php echo $i; ?>">
                                            <h4 class="panel-title">
                                                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $i; ?>" aria-expanded="false" aria-controls="collapse<?php echo $i; ?>">
                                                    <?php the_title(); ?>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapse<?php echo $i; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo $i; ?>">
                                            <div class="panel-body">
                                                <?php the_content(); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile;wp_reset_postdata(); ?>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="contact-area">

                        <div class="section-title">
                            <h3>Request
                                <span>Appointment</span>
                            </h3>
                        </div>
                        <?php
                        $code = get_post_meta(get_the_ID(),'contact_shortcode',true);
                        if( $code == '') :
                            ?>
                            <form name="contact_form" class="default-form contact-form" action="sendmail.php" method="post">
                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <input type="text" name="Name" placeholder="Name" required="">
                                        </div>
                                        <div class="form-group">
                                            <input type="email" name="Email" placeholder="Email" required="">
                                        </div>
                                        <div class="form-group">
                                            <select name="subject">
                                                <option>Departments</option>
                                                <option>Diagnostic</option>
                                                <option>Psychological</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <input type="text" name="Phone" placeholder="Phone" required="">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="Date" placeholder="Date" required="" id="datepicker">
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                        </div>
                                        <div class="form-group">
                                            <select name="subject">
                                                <option>Doctor</option>
                                                <option>Diagnostic</option>
                                                <option>Psychological</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <textarea name="form_message" placeholder="Your Message" required=""></textarea>
                                        </div>
                                        <div class="form-group text-center">
                                            <button type="submit" class="btn-style-one">submit now</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        <?php else : ?>
                            <?php echo do_shortcode($code); ?>
                        <?php endif; ?>


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Contact Section -->

<?php get_footer(); ?>