<?php get_header();
global $coder;
/* Template Name:Gallery */
?>

<!--Page Title-->
<section class="page-title text-center" style=" background-color:<?php echo $coder['page_bg']['background-color'];?>;
        background-repeat:<?php echo $coder['page_bg']['background-repeat'];?>;
        background-size:<?php echo $coder['page_bg']['background-size'];?>;
        background-attachment:<?php echo $coder['page_bg']['background-attachment'];?>;
        background-position:<?php echo $coder['page_bg']['background-position'];?>;
        background-image:url(<?php echo $coder['page_bg']['background-image']; ?>);">
    <div class="container">
        <div class="title-text">
            <h1><?php the_title(); ?></h1>
            <ul class="title-menu clearfix">
                <li>
                    <a href="<?php home_url(); ?>">home &nbsp;/</a>
                </li>
                <li><?php wp_title(' '); ?></li>
            </ul>
        </div>
    </div>
</section>
<!--End Page Title-->

<section class="video-gallery">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h3><?php echo get_post_meta(get_the_ID(),'gallery_service_title',true); ?></h3>
                    <p><?php echo get_post_meta(get_the_ID(),'gallery_service_title_desc',true); ?></p>
                </div>
            </div>
                <?php

                $shot = new WP_Query(array(
                    'post_type' => 'Collected_media',
                    'posts_per_page' => -1
                ));
                while($shot->have_posts()) : $shot->the_post();
                    ?>
                  <div class="col-sm-6">
                <div class="video-gallery-item">
                    <div class="image-holder">
                        <?php
                        $img_url = wp_get_attachment_url(get_post_thumbnail_id());
                        ?>
                        <img src="<?php echo $img_url; ?>" class="img-responsive" alt="video-gallery">
                        <a data-fancybox href="<?php echo get_post_meta(get_the_ID(),'media_v_url',true); ?>"><i class="fa fa-play"></i></a>
                    </div>
                    <h3><?php the_title(); ?></h3>
                </div>
            </div>

                <?php endwhile;wp_reset_postdata(); ?>
        </div>
    </div>
</section>

    <section class="gallery bg-gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title text-center">
                        <h3><?php echo get_post_meta(get_the_ID(),'g_title_s',true); ?></h3>
                        <p><?php echo get_post_meta(get_the_ID(),'g_sub_desc',true); ?></p>
                    </div>
                </div>
                <?php

                $shot = new WP_Query(array(
                    'post_type' => 'medic_shots',
                    'posts_per_page' => -1
                ));
                while($shot->have_posts()) : $shot->the_post();
                    ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="gallery-item" >
                            <?php the_post_thumbnail(); ?>
                            <?php
                            $img_url = wp_get_attachment_url(get_post_thumbnail_id());
                            ?>
                            <a data-fancybox="images" href="<?php echo $img_url; ?>"></a>
                            <h3><?php the_title(); ?></h3>
                            <?php the_content(); ?>
                        </div>
                    </div>
                <?php endwhile;wp_reset_postdata(); ?>


            </div>
    </section>

<?php get_footer(); ?>