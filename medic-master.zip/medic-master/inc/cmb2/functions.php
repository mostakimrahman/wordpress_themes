<?php

function metabox_for_collected_media() {


    $cmb_demo = new_cmb2_box( array(
        'id'            =>'media_video_url',
        'title'         => 'Galery Page media video',
        'object_types'  => array( 'Collected_media' ), // Post type
    ) );

    $cmb_demo->add_field( array(
        'name'       => 'Media Video Url',
        'desc'       => 'Add Media video url',
        'id'         => 'media_v_url',
        'type'       => 'text',
    ) );
}
add_action( 'cmb2_admin_init', 'metabox_for_collected_media' );



add_action('cmb2_admin_init','amader_cmb2_function');
function amader_cmb2_function(){

    $medic_opt = new_cmb2_box(array(
        'title' => 'Slider Options',
        'id'	=> 'slider_opt',
        'object_types' => array('slider'),
        'priority' => 'high'
    ));
    $medic_opt-> add_field(array(
        'name' => 'Button Text',
        'type'	=> 'text',
        'id'	=> 'slider_btn',
        'default' => 'Explore'
    ));
    $medic_opt->add_field(array(
        'name'	=> 'Button URL',
        'type'	=> 'text_url',
        'id'	=> 'slider_btn_url',
        'default' => '#'
    ));
    $medic_opt->add_field(array(
        'name'	=> 'Content Position',
        'type'	=> 'select',
        'id'	=> 's_content_p',
        'desc' => 'Please select your slider content position',
        'options' => array(
            'center' => 'Position Center',
            'left' => 'Position Left',
            'right' => 'Position Right',
        )
    ));
    // Services
    $medic_service = new_cmb2_box(array(
        'title'	=> 'Services Options',
        'id'	=> 'medic_service',
        'object_types' => array('services')
    ));
    $medic_service->add_field(array(
        'name'	=> 'Service Title',
        'type'	=> 'text',
        'id'	=> 's_title',
        'default'=> 'dormitory'
    ));
    $medic_service->add_field(array(
        'name'	=> 'Service Subtitle',
        'type'	=> 'text',
        'id'	=> 's_sub_title',
        'default'=> 'Better Service At Low Cost'
    ));
    $medic_service->add_field(array(
        'name'	=> 'Service Tab ID',
        'type'	=> 'text',
        'id'	=> 's_tab_id',
        'default'=> 'ID1',
        'desc' => 'Please change the ID per Service'
    ));
    $medic_service->add_field(array(
        'name'	=> 'Service Image',
        'type'	=> 'file',
        'id'	=> 's_img',
        'options' => array(
            'url' => false
        ),
        'text'	=> array(
            'add_upload_file_text' => 'Upload Service Image'
        )
    ));
    $medic_service->add_field(array(
        'name'	=> 'Service Description',
        'type'	=> 'wysiwyg',
        'id'	=> 's_description',
        'default' => '
		<div class="text">
                                        <p>The implant fixture is first placed, so that it ilikely to osseointegrate, then a dental prosthetic is added. then a
                                            dental prosthetic is added.then a dental pros- thetic is added.</p>
                                            <p>The implant fixture is first placed, so that it ilikely to osseointegrate, then a dental prosthetic is added. then a dental
                                                prosthetic is added.then a dental pros- thetic is added.</p>
                                    </div>


          <ul class="content-list">
                                        <li>
                                            <i class="fa fa-dot-circle-o"></i>Whitening is among the most popular dental</li>
                                        <li>
                                            <i class="fa fa-dot-circle-o"></i>Teeth cleaning is part of oral hygiene and involves</li>
                                        <li>
                                            <i class="fa fa-dot-circle-o"></i>Teeth cleaning is part of oral hygiene and involves</li>
                                    </ul>
		'
    ));
    $medic_service->add_field(array(
        'name'	=> 'Service Button URL',
        'type'	=> 'text_url',
        'id'	=> 's_btn',
        'default'=> '#'
    ));


    // Doctors
    $medic_doctor = new_cmb2_box(array(
        'title'	=> 'Doctors Details',
        'id'	=> 'doctors',
        'object_types'=> array('doctors')
    ));
    $medic_doctor-> add_field(array(
        'name'	=> 'Doctor Name',
        'type'	=> 'text',
        'id'	=> 'd_name',
        'default'=> 'Dr. Robert Barrethion'
    ));
    $medic_doctor-> add_field(array(
        'name'	=> 'Doctor Description',
        'type'	=> 'textarea',
        'id'	=> 'd_desc',
        'default'=> 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dignissimos, aspernatur.'
    ));
    $medic_doctor-> add_field(array(
        'name'	=> 'Doctor Picture',
        'type'	=> 'file',
        'id'	=> 'd_img'
    ));
    $medic_doctor-> add_field(array(
        'name'	=> 'Read More URL',
        'type'	=> 'text_url',
        'id'	=> 'd_btn',
        'default'=> '#'
    ));

    // About Template Options
    $about = new_cmb2_box(array(
        'title'	=> 'About Page Options',
        'id'	=> 'about_p',
        'object_types' => array('page'),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-about.php' ),
    ));
    $about-> add_field(array(
        'name'	=> 'Title',
        'type'	=> 'text',
        'id'	=> 'story_title',
        'default'=> 'Our Story'
    ));
    $about->add_field(array(
        'name'	=> 'Our Story Image',
        'type'	=> 'file',
        'id'	=> 'story_img'
    ));
    $about->add_field(array(
        'name'	=> 'Our Story Description',
        'type'	=> 'wysiwyg',
        'id'	=> 'story_desc',
        'default' => ' <h5 class="tagline">"Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsum, minima."</h6>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus totam ducimus est vero, officiis, placeat optio. Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias aliquam nesciunt fugit optio illum aut. Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque assumenda, est quam perferendis expedita autem?</p>
                    <h6>Mission</h6>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam nihil dolorum beatae consequatur mollitia iure?</p>
                    <h6>Vision</h6>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda consectetur adipisci, voluptatum dolores nostrum omnis.</p>

		'
    ));

    $about->add_field(array(
        'name'	=> 'Video Title',
        'id'	=> 'video_title',
        'type'	=> 'text',
        'default' => 'About Our Hospital'
    ));
    $about->add_field(array(
        'name'	=> 'Video Subtitle',
        'id'	=> 'video_sub_title',
        'type'	=> 'textarea',
        'default' => 'The World <br> Class Hospitality '
    ));
    $about->add_field(array(
        'name'	=> 'Video ID',
        'id'	=> 'video_id',
        'type'	=> 'text',
        'default' => '_sI_Ps7JSEk',
        'desc' => 'Example: https://www.youtube.com/watch?v=_sI_Ps7JSEk'
    ));
    $about->add_field(array(
        'name'	=> 'Video Background',
        'id'	=> 'video_bg',
        'type'	=> 'file'
    ));


    //Service page
    $service = new_cmb2_box(array(
        'title'	=> 'Service Page Options',
        'id'	=> 'about_s',
        'object_types' => array('page'),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-service.php' ),
    ));
    $service-> add_field(array(
        'name'	=> 'Service Title',
        'type'	=> 'wysiwyg',
        'id'	=> 'service_title',
        'default'=> '<h2>Clinical And <br>Medical Education</h2>'
    ));
    $service-> add_field(array(
        'name'	=> 'Service Desc',
        'type'	=> 'wysiwyg',
        'id'	=> 'service_desc',
        'default'=> '<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas eius optio repellendus quasi nisi vitae laboriosam explicabo eligendi sapiente in.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae, dolorum esse tempora id architecto laboriosam.
                    </p>
                    <ul>
                        <li><i class="fa fa-caret-right"></i>vitae laboriosam explicabo eligendi sapiente</li>
                        <li><i class="fa fa-caret-right"></i>consectetur adipisicing elit. Beatae</li>
                        <li><i class="fa fa-caret-right"></i>dolorum esse tempora id architecto</li>
                        <li><i class="fa fa-caret-right"></i>optio repellendus quasi nisi vitae</li>
                    </ul>'
    ));
    $service-> add_field(array(
        'name'	=> 'Service Button',
        'type'	=> 'text',
        'id'	=> 'service_btn',
        'default'=> 'Appoint'
    ));
    $service-> add_field(array(
        'name'	=> 'Service Button Url',
        'type'	=> 'text',
        'id'	=> 'service_btn_url',
        'default'=> '#'
    ));
    $service-> add_field(array(
        'name'	=> 'Service name',
        'type'	=> 'text',
        'id'	=> 'service_ne',
        'default'=> 'pulmonary'
    ));
    $service-> add_field(array(
        'name'	=> 'Service Image',
        'type'	=> 'file',
        'id'	=> 'service_im',

    ));
    $service-> add_field(array(
        'name'	=> 'Service Details',
        'type'	=> 'wysiwyg',
        'id'	=> 'service_de',
        'default'=> '<div class="text">
                                <p>The implant fixture is first placed, so that it ilikely to osseointegrate, then a dental prosthetic is added.
                                    then a dental prosthetic is added.then a dental pros- thetic is added.</p>
                                <p>The implant fixture is first placed, so that it ilikely to osseointegrate, then a dental prosthetic is added.
                                    then a dental prosthetic is added.then a dental pros- thetic is added.</p>
                            </div>
                            <ul class="content-list">
                                <li>
                                    <i class="fa fa-check-circle-o"></i>Whitening is among the most popular dental</li>
                                <li>
                                    <i class="fa fa-check-circle-o"></i>Teeth cleaning is part of oral hygiene and involves</li>
                                <li>
                                    <i class="fa fa-check-circle-o"></i>Teeth cleaning is part of oral hygiene and involves</li>
                            </ul>'
    ));
    $service-> add_field(array(
        'name'	=> 'Service Btn2',
        'type'	=> 'text',
        'id'	=> 'service_btn2',
        'default'=> 'Read more'
    ));
    $service-> add_field(array(
        'name'	=> 'Service Button2 Url',
        'type'	=> 'text',
        'id'	=> 'service_btn2_url',
        'default'=> '#'
    ));

    $service-> add_field(array(
        'name'	=> 'Service Provided',
        'type'	=> 'wysiwyg',
        'id'	=> 'service_p',
        'default'=> '<h3>Provided <span> 
                        Services</span></h3>'
    ));

    $service-> add_field(array(
        'name'	=> 'Service Provided Desc',
        'type'	=> 'textarea',
        'id'	=> 'service_pro_desc',
        'default'=> '<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Lorem ipsum dolor sit amet. qui suscipit atque <br>
                fugiat officia corporis rerum eaque neque totam animi, sapiente culpa. Architecto!</p>'
    ));
    //Gallery
    $gallery = new_cmb2_box(array(
        'title'	=> 'Gallery Page Options',
        'id'	=> 'gallery_s',
        'object_types' => array('page'),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-gallery.php' ),
    ));
    $gallery-> add_field(array(
        'name'	=> 'Gallery Service Title',
        'type'	=> 'wysiwyg',
        'id'	=> 'gallery_service_title',
        'default'=> '<h3>Collected Media
                        <span>of Our Hospital</span>
                    </h3>'
    ));
    $gallery-> add_field(array(
        'name'	=> 'Gallery Service Desc',
        'type'	=> 'wysiwyg',
        'id'	=> 'gallery_service_title_desc',
        'default'=> ' <p>Leverage agile frameworks to provide a robust synopsis for high level overv-
                        <br>iews. Iterative approaches to corporate strategy...</p>'
    ));
    $gallery->add_field(array(
        'name'	=> 'Gallery Shot section title',
        'id'	=> 'g_title_s',
        'type'	=> 'textarea',
        'default'	=> 'Collected Shots
                        <span>of Our Hospital</span>
                    '
    ));
    $gallery->add_field(array(
        'name'	=> 'Gallery Shot section Description',
        'id'	=> 'g_sub_desc',
        'type'	=> 'textarea',
        'default'	=> 'Leverage agile frameworks to provide a robust synopsis for high level overv- iews. Iterative approaches to corporate strategy...'
    ));


    // Shot section
    $about->add_field(array(
        'name'	=> 'Shot section title',
        'id'	=> 's_title_s',
        'type'	=> 'textarea',
        'default'	=> 'Collected Shots
                        <span>of Our Hospital</span>
                    '
    ));
    $about->add_field(array(
        'name'	=> 'Shot section Description',
        'id'	=> 's_sub_desc',
        'type'	=> 'textarea',
        'default'	=> 'Leverage agile frameworks to provide a robust synopsis for high level overv- iews. Iterative approaches to corporate strategy...'
    ));
    $about->add_field(array(
        'name'	=> 'Shot Posts Limit',
        'id'	=> 's_post_limit',
        'type'	=> 'text',
        'default'	=> 6
    ));

    // Faq
    $about->add_field(array(
        'name'	=> 'FAQ Title',
        'id'	=> 'faq_titles',
        'type'	=> 'text',
        'default'	=> 'FAQ'
    ));

    $about->add_field(array(
        'name'	=> 'Contact Form Shortcode',
        'id'	=> 'contact_shortcode',
        'type'	=> 'text'
    ));


    // Contact Template Options
    $contact = new_cmb2_box(array(
        'title'	=> 'Contact Page Options',
        'id'	=> 'contact_opt',
        'object_types' => array('page'),
        'show_on'      => array( 'key' => 'page-template', 'value' => 'template-contact.php' ),
    ));

    $contact->add_field(array(
        'name'	=> 'Location',
        'id'	=> 'c_location',
        'type'	=> 'textarea',
        'default' => 'PO Box 16122 Collins Street West<br>Victoria 8007 Canada'
    ));
    $contact->add_field(array(
        'name'	=> 'Phone Numbers',
        'id'	=> 'c_phones',
        'type'	=> 'textarea',
        'default' => '(+48) 564-334-21-22-34<br>(+48) 564-334-21-22-38'
    ));
    $contact->add_field(array(
        'name'	=> 'Email',
        'id'	=> 'c_emails',
        'type'	=> 'textarea',
        'default' => 'info@templatepath.com <br>info@cleanxer.com'
    ));

    $contact->add_field(array(
        'name'	=> 'Contact Form Shortcode',
        'id'	=> 'c_shortcode',
        'type'	=> 'text'
    ));

}

