<?php 

add_action('after_setup_theme','medic_theme_setup');
function medic_theme_setup(){
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');


	// Main Menu 
	register_nav_menus(array(
		'main-menu'=>'Main Menu',
		'footer-menu'=> 'Footer Menu'
	));

	// Slider 
	register_post_type('slider',array(
		'labels' => array(
			'name' => 'Slider',
			'add_new' => 'Add New Slide',
			'add_new_item' => 'Add New Slide',
			'featured_image'=> 'Slide Image'
		),
		'public' => true,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array('title','editor','thumbnail')
	));

	// Best Featured 
	register_post_type('best_featured',array(
		'labels' => array(
			'name' => 'Best Featured',
			'add_new' => 'Add New Feature',
			'add_new_item' => 'Add New Feature',
			'featured_image'=> 'Feature Image'
		),
		'public' => true,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array('title','editor','thumbnail')
	));

	// Services 
	register_post_type('services',array(
		'labels' => array(
			'name' => 'Services',
			'add_new' => 'Add New Service',
			'add_new_item' => 'Add New Service'
		),
		'public' => true,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array('title')
	));

	// Doctors 
	register_post_type('doctors',array(
		'labels' => array(
			'name' => 'Our Doctors',
			'add_new' => 'Add New Doctor',
			'add_new_item' => 'Add New Doctor'
		),
		'public' => true,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array('title')
	));

	// Reviews 
	register_post_type('review',array(
		'labels' => array(
			'name' => ' Patients Review',
			'add_new' => 'Add New Review',
			'add_new_item' => 'Add New Review'
		),
		'public' => true,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array('title','editor','thumbnail')
	));

	// Reviews 
	register_post_type('faq',array(
		'labels' => array(
			'name' => ' FAQs',
			'add_new' => 'Add New Faq',
			'add_new_item' => 'Add New Faq'
		),
		'public' => true,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array('title','editor')
	));

	// Reviews 
	register_post_type('medic_shots',array(
		'labels' => array(
			'name' => 'Collected Shots',
			'add_new' => 'Add New Shot',
			'add_new_item' => 'Add New Shot'
		),
		'public' => true,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array('title','editor','thumbnail')
	));

}


add_action('widgets_init','medic_widgets');
function medic_widgets(){

	// Footer Widgets
	register_sidebar(array(
		'name' => 'Footer 1 Widget',
		'id'	=> 'footer_1_w',
		'description' => 'here set your footer widgets',
		'before_title' => '<h6>',
		'after_title' => '</h6>',
		'before_widget' => '<div class="col-md-4 col-sm-6 col-xs-12">',
		'after_widget' => '</div>'
	));

	// Blog Sidebar
	register_sidebar(array(
		'name'	=> 'Blog Sidebar',
		'id'	=> 'blog_sidebar',
		'description'	=> 'Add your blog Widgets',
		'before_title' => '<div class="text-title"><h6>',
		'after_title' => '</h6></div><ul class="categorise-list">',
		'before_widget' => '</ul>   <div class="categorise-menu">',
		'after_widget' => '</div>',
	));

}

add_action('wp_enqueue_scripts','medic_css_js');
function medic_css_js(){
	// CSS Files
	wp_register_style('slick',get_template_directory_uri().'/plugins/slick/slick.css');
	wp_enqueue_style('slick');
	wp_enqueue_style('slick-theme',get_template_directory_uri().'/plugins/slick/slick-theme.css');
	wp_enqueue_style('fancybox',get_template_directory_uri().'/plugins/fancybox/jquery.fancybox.min.css');
	wp_enqueue_style('style',get_template_directory_uri().'/css/style.css');
	wp_enqueue_style('main-style',get_stylesheet_uri());

	// JS Files 
	wp_enqueue_script('jquery');
	wp_enqueue_script('bootstrap',get_template_directory_uri().'/plugins/bootstrap.min.js',array('jquery'),'1.0',true);
	wp_enqueue_script('bootstrap-select',get_template_directory_uri().'/plugins/bootstrap-select.min.js',array('jquery'),'1.0',true);
	wp_enqueue_script('slick-js',get_template_directory_uri().'/plugins/slick/slick.min.js',array('jquery'),'1.0',true);
	wp_enqueue_script('fancybox-js',get_template_directory_uri().'/plugins/fancybox/jquery.fancybox.min.js',array('jquery'),'1.0',true);
	wp_enqueue_script('validate',get_template_directory_uri().'/plugins/validate.js',array('jquery'),'1.0',true);
	wp_enqueue_script('wow',get_template_directory_uri().'/plugins/wow.js',array('jquery'),'1.0',true);
	wp_enqueue_script('gmap-api','https://maps.googleapis.com/maps/api/js?key=AIzaSyCw-BKYqt_gpvdrB6kAu30hN8t_jugXaPU',array('jquery'),'1.0',true);
	wp_enqueue_script('gmap',get_template_directory_uri().'/plugins/google-map/gmap.js',array('jquery'),'1.0',true);
	wp_enqueue_script('jquery-ui',get_template_directory_uri().'/plugins/jquery-ui.js',array('jquery'),'1.0',true);
	wp_enqueue_script('timePicker',get_template_directory_uri().'/plugins/timePicker.js',array('jquery'),'1.0',true);
	wp_enqueue_script('script',get_template_directory_uri().'/js/script.js',array('jquery'),'1.0',true);
 

}





// Footer Recent Posts Widgets Shortcode 
add_shortcode('medic_recent_post','medic_recent_function');
function medic_recent_function($atts,$content){

	$recent_atts = shortcode_atts(array(
		'count' => 3
	),$atts);
	extract($recent_atts);

	ob_start();
	?>
  <div class="social-links ">
    <ul>
     <?php 
     $recent_post  = new WP_Query(array(
     	'post_type' => 'post',
     	'posts_per_page' => $count,
     	'order' =>'ASC'
     ));
     while($recent_post->have_posts()): $recent_post->the_post(); ?>
      <li class="item">
        <div class="media">
          <div class="media-left">
            <a href="<?php the_permalink(); ?>">
              <?php
             	 $thumb_url = wp_get_attachment_url(get_post_thumbnail_id());
              ?>
              <img style="width:80px;height:auto" class="media-object" src="<?php echo $thumb_url;?>" alt="post-thumb">
            </a>
          </div>
          <div class="media-body">
            <h4 class="media-heading"><a href="<?php the_permalink(); ?>"><?php echo the_title(); ?></a></h4>
            <p><?php echo wp_trim_words(get_the_content(),11,'...'); ?></p>
          </div>
        </div>
      </li>
     <?php endwhile;wp_reset_postdata(); ?>
    </ul>
  </div>

	<?php 
	$output = ob_get_clean();
	return $output;
}

add_action( 'admin_init', 'hide_editor' );
function hide_editor() {
	$post_id = $_GET['post'] ? $_GET['post'] : $_POST['post_ID'] ;
	if( !isset( $post_id ) ) return;
	$template_file = get_post_meta($post_id, '_wp_page_template', true);
    if($template_file == 'template-about.php' || $template_file == 'template-contact.php'){ // edit the template name
    	remove_post_type_support('page', 'editor');
    }
}

// Shortcodes
require_once('shortcode/slider.php');
require_once('shortcode/featured.php');
require_once('shortcode/best-featured.php');
require_once('shortcode/service-tabs.php');
require_once('shortcode/service-slide.php');
require_once('shortcode/ourDOctors.php');
require_once('shortcode/review.php');
require_once('shortcode/faq.php');

// Require Files

require_once('inc/medic-redux/ReduxCore/framework.php');
require_once('inc/medic-redux/sample/config.php');
require_once('inc/cmb2/init.php');
require_once('inc/cmb2/functions.php');
require_once('inc/medic-demo-content/medic-demo-content.php');
