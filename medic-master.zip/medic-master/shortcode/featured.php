<?php 
add_shortcode('featured','featured_function');
function featured_function(){
	global $coder;
	ob_start();?>
<section class="cta">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="cta-block">
                    <div class="emmergency item">
                        <i class="fa <?php echo $coder['e_icon_name'];?>"></i>
                        <h2><?php echo $coder['e_title'];?></h2>
                        <a href="tel:<?php echo $coder['e_phone'];?>"><?php echo $coder['e_phone'];?></a>
                        <p><?php echo $coder['e_desc'];?></p>
                    </div>
                    <div class="top-doctor item">
                        <i class="fa <?php echo $coder['h_icon_name'];?>"></i>
                        <h2><?php echo $coder['h_title'];?></h2>
                        <p><?php echo $coder['h_desc'];?></p>
                        <a href="<?php echo $coder['h_btn'];?>" class="btn btn-main">Read more</a>
                    </div>
                    <div class="working-time item">
                        <i class="fa <?php echo $coder['w_icon_name'];?>"></i>
                        <h2><?php echo $coder['w_title'];?></h2>
                        <?php echo $coder['w_h_table'];?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

	
	<?php 
	return ob_get_clean();
}

if(function_exists('vc_map')){
    vc_map(array(
        'name' => 'Medic Featured',
        'base' => 'featured',
        'category' => 'Medic Elements',
        'params' => array()

    ));
}