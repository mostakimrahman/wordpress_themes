<?php 
add_shortcode('service_carousel','service_carousel_function');
function service_carousel_function($atts,$content){
    extract(shortcode_atts(array(
        'title' => 'Provided<span>Services</span>',
        'desc'  => 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Lorem ipsum dolor sit amet. qui suscipit atque <br>
                fugiat officia corporis rerum eaque neque totam animi, sapiente culpa. Architecto!'
    ),$atts));
	ob_start();?>
<section class="service-section bg-gray section">
    <div class="container">
        <div class="section-title text-center">
            <h3><?php echo $title; ?></h3>
            <p><?php echo $desc; ?></p>
        </div>
        <div class="row items-container clearfix">
             <?php 
                $service_links = new WP_Query(array(
                    'post_type' => 'services',
                    'posts_per_page' => -1
                ));
                while($service_links->have_posts()) : $service_links->the_post()  ?>
            <div class="item">
                <div class="inner-box">
                    <div class="img_holder">
                        <a href="service.html">
                            <img src="<?php echo get_post_meta(get_the_ID(),'s_img',true); ?>" alt="images" class="img-responsive">
                        </a>
                    </div>
                    <div class="image-content text-center">
                        <span><?php echo get_post_meta(get_the_ID(),'s_sub_title',true); ?></span>
                        <a href="<?php the_permalink(); ?>">
                            <h6><?php the_title(); ?></h6>
                        </a>
                        <p><?php
                        $content = get_post_meta(get_the_ID(),'s_description',true);
                         echo wp_trim_words($content,10,' '); ?></p>
                    </div>
                </div>
            </div>
           <?php endwhile; ?>
        </div>
    </div>
</section>
	<?php return ob_get_clean();
}


if(function_exists('vc_map')){
vc_map(array(

    'name' => 'Service Carousel',
    'base' => 'service_carousel',
    'category' => 'Medic Elements',
    'icon'  => get_template_directory_uri().'/images/icon.png',
    'description' => 'Here Best Service Options',
    'params' => array(
        array(
            'heading' => 'Section Title',
            'type'  => 'textfield',
            'param_name' => 'title',
            'value' => 'Provided<span>Services</span>',
            'description' => 'Here write your section title'
        ),
        array(
            'heading' => 'Section Description',
            'type'  => 'textarea',
            'param_name' => 'desc',
            'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam magni in at debitis'
        )
    )
));
}

