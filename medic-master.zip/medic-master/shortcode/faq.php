<?php 
add_shortcode('faq','faq_function');
function faq_function($atts,$content){
	extract(shortcode_atts(array(
		'title_1' => 'FAQ',
        'title_2' => 'Request<span>Appointment</span>',
	),$atts));
	ob_start();?>
<section class="appoinment-section section">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="accordion-section">
    <div class="section-title">
        <h3><?php echo $title_1; ?></h3>
    </div>
    <div class="accordion-holder">
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
            <?php 
            $faq = new WP_Query(array(
            	'post_type' => 'faq',
            	'posts_per_page' => -1
            ));
            $i=0;
            while($faq->have_posts()) : $faq->the_post();
            	$i++;
             ?>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="heading<?php echo $i; ?>">
                    <h4 class="panel-title">
                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $i; ?>" aria-expanded="false" aria-controls="collapse<?php echo $i; ?>">
                           <?php the_title(); ?>
                        </a>
                    </h4>
                </div>
                <div id="collapse<?php echo $i; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo $i; ?>">
                    <div class="panel-body">
                       <?php the_content(); ?>
                    </div>
                </div>
            </div>
          	<?php endwhile; ?>
        </div>
    </div>
</div>
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="contact-area">
    <div class="section-title">
        <h3><?php echo $title_2; ?></h3>
    </div>
    <?php echo do_shortcode($content); ?>


</div>                        
            </div>
        </div>                    
    </div>
</section>

	<?php  return ob_get_clean();
}



if(function_exists('vc_map')){
vc_map(array(

    'name' => 'FAQs',
    'base' => 'faq',
    'category' => 'Medic Elements',
    'icon'  => get_template_directory_uri().'/images/icon.png',
    'params' => array(
        array(
            'heading' => 'Title 1',
            'type'  => 'textfield',
            'param_name' => 'title_1',
            'value' => 'FAQ'
        ),
        array(
            'heading' => 'Title 2',
            'type'  => 'textfield',
            'param_name' => 'title_2',
            'value' => 'Request<span>Appointment</span>'
        ),
        array(
            'heading' => 'Form Shortcode',
            'type'  => 'textarea_html',
            'param_name' => 'content'
        ),
    )
));
}

