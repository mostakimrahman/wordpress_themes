<?php 
add_shortcode('review','review_function');
function review_function($atts,$content){
    $review_atts = shortcode_atts(array(
        'title' => 'What Our <span>Patients Says</span>',
        'bg' => get_template_directory_uri().'/images/testimonials/1.jpg'
    ),$atts);
    extract($review_atts);
    ob_start();
    ?>

<?php 
    $img_url = wp_get_attachment_image_src($bg,'full');
 ?>


<section class="testimonial-section" style="background: url(<?php echo $img_url[0]; ?>);">
    <div class="container">
        <div class="section-title text-center">
            <h3><?php echo $title; ?></h3>
        </div>
        <div class="testimonial-carousel">
             <?php 
               $review = new WP_Query(array(
                'post_type' => 'review',
                'posts_per_page' => -1
               ));
               while($review->have_posts()) :  $review->the_post();
            ?>
            <div class="slide-item">
                <div class="inner-box text-center">
                    <div class="image-box">
                        <figure>
                           <?php the_post_thumbnail(); ?>
                        </figure>
                    </div>
                    <h6><?php the_title(); ?></h6>
                    <p><?php the_content(); ?></p>
                </div>
            </div>
           <?php endwhile; ?>
        </div>
    </div>
</section>
    <?php return ob_get_clean();
}



if(function_exists('vc_map')){
vc_map(array(

    'name' => 'Client Reviews',
    'base' => 'review',
    'category' => 'Medic Elements',
    'icon'  => get_template_directory_uri().'/images/icon.png',
    'params' => array(
        array(
            'heading' => 'Section Title',
            'type'  => 'textfield',
            'param_name' => 'title',
            'value' => 'What Our <span>Patients Says</span>',
            'description' => 'Here write your section title'
        ),
        array(
            'heading' => 'Background Image',
            'type'  => 'attach_image',
            'param_name' => 'bg',
            'value' => get_template_directory_uri().'/images/testimonials/1.jpg'
        )
    )
));
}

