<?php get_header();
global $coder;
/* Template Name:Appointment */
?>

<!--Page Title-->
<section class="page-title text-center" style="background-color:<?php echo $coder['page_bg']['background-color'];?>;
        background-repeat:<?php echo $coder['page_bg']['background-repeat'];?>;
        background-size:<?php echo $coder['page_bg']['background-size'];?>;
        background-attachment:<?php echo $coder['page_bg']['background-attachment'];?>;
        background-position:<?php echo $coder['page_bg']['background-position'];?>;
        background-image:url(<?php echo $coder['page_bg']['background-image']; ?>);">
    <div class="container">
        <div class="title-text">
            <h1>appointment</h1>
            <ul class="title-menu clearfix">
                <li>
                    <a href="index.html">home &nbsp;/</a>
                </li>
                <li>appointment</li>
            </ul>
        </div>
    </div>
</section>
<!--End Page Title-->

<!-- Contact Section -->
<section class="blog-section section style-three pb-0">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="contact-area style-two">
                    <div class="section-title">
                        <h3>Request <span>Appointment</span></h3>
                    </div>


                        <?php echo do_shortcode('[contact-form-7 id="116" title="Appointment"]'); ?>

                </div>                      
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="appointment-image-holder">
                    <figure>
                        <img src="<?php echo get_template_directory_uri();?>/images/background/appoinment.jpg" alt="Appointment">
                    </figure>
                </div>                       
            </div>
        </div>                    
    </div>
</section>
<!-- End Contact Section -->

<!--team section-->
<?php echo do_shortcode("[doctors]"); ?>
<!--End team section-->

<?php get_footer(); ?>