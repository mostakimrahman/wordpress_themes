<?php get_header(); ?>


<div class="error-arae">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>404 Not Found</h1>
				<a href="<?php home_url(); ?>">Back to home</a>
			</div>
		</div>
	</div>
</div>


<?php get_footer(); ?>